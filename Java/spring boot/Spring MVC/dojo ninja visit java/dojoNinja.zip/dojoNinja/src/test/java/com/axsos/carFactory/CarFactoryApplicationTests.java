package com.axsos.carFactory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarFactoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
